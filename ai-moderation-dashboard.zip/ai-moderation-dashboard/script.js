async function moderateText() {
    const text = document.getElementById("singleText").value;

    const response = await fetch("https://meanwhile-subpericardiac-huey.ngrok-free.dev/moderate",
        {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: text })
        }
    );

    const data = await response.json();
    singleResult.innerText = resultText;
} 




/* --- DOM --- */
const navBtns = document.querySelectorAll('.nav-btn');
const panels = document.querySelectorAll('.panel');







const statTotal = document.getElementById('statTotal');
const statApproved = document.getElementById('statApproved');
const statRejected = document.getElementById('statRejected');
const statUnsafePct = document.getElementById('statUnsafePct');
const recentActionsList = document.getElementById('recentActions');

const globalSearch = document.getElementById('globalSearch');
const refreshBtn = document.getElementById('refreshBtn');


// --- Navigation
navBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    navBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const target = btn.dataset.target;
    panels.forEach(p => p.classList.remove('active-panel'));
    document.getElementById(target).classList.add('active-panel');
  });
});

/* ---------------------------------------------------
   SINGLE TEXT MODERATION
-----------------------------------------------------*/

// UI Elements
const singleText = document.getElementById("singleText");
const moderateSingleBtn = document.getElementById("moderateSingleBtn");
const clearSingleBtn = document.getElementById("clearSingleBtn");
const singleResultArea = document.getElementById("singleResultArea");
const singleResult = document.getElementById("singleResult");

// Replace with your ngrok URL
const API_URL = "https://meanwhile-subpericardiac-huey.ngrok-free.dev/moderate";

// Event → When user clicks "Moderate"
moderateSingleBtn.addEventListener("click", async () => {
    const text = singleText.value.trim();

    if (!text) {
        alert("Please enter text to moderate.");
        return;
    }

    // Call backend
    let response;
    try {
        response = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text })
        });
    } catch (err) {
        console.error("Network error:", err);
        singleResult.innerHTML = "❌ Network Error: Could not connect to server.";
        singleResultArea.classList.remove("hidden");
        return;
    }

    let data;
    try {
        data = await response.json();
        console.log("Backend JSON →", data);
    } catch (err) {
        console.error("JSON parse error:", err);
        singleResult.innerHTML = "❌ Error: Server did not return valid JSON.";
        singleResultArea.classList.remove("hidden");
        return;
    }

    // Get moderation result
    let result = data.moderation_result || data.result || data;

    // Convert to object if needed
    if (typeof result === "string") {
        try {
            result = JSON.parse(result);
        } catch (e) {
            console.warn("Could not parse JSON string");
        }
    }

    // FINAL CLEAN OUTPUT
    singleResultArea.classList.remove("hidden");

    if (result.category && result.action && result.reason) {
        singleResult.innerHTML = `
            <div><strong>Category:</strong> ${result.category}</div>
            <div><strong>Action:</strong> ${result.action}</div>
            <div><strong>Reason:</strong> ${result.reason}</div>
        `;
    } else {
        singleResult.innerHTML = `
            <strong>Raw Output:</strong><br>
            <pre>${JSON.stringify(result, null, 2)}</pre>
        `;
    }
});

// Clear button
clearSingleBtn.addEventListener("click", () => {
    singleText.value = "";
    singleResultArea.classList.add("hidden");
});




/* -----------------------------------------------------------
   BATCH MODERATION — Paste + Upload + Table Rendering
------------------------------------------------------------- */

// UI Elements
const batchPaste = document.getElementById('batchPaste');
const fileUpload = document.getElementById('fileUpload');
const processBatchBtn = document.getElementById('processBatchBtn');
const clearBatchBtn = document.getElementById('clearBatchBtn');
const exportCsvBtn = document.getElementById('exportCsvBtn');

const resultsTableBody = document.querySelector('#resultsTable tbody');

// state
let results = [];
let nextId = 1;
let recentActions = [];

/* -----------------------------------------
  Helper: Read uploaded file as text
----------------------------------------- */
function readFileAsText(file) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result);
    fr.onerror = reject;
    fr.readAsText(file);
  });
}

/* -----------------------------------------------------
   Main Batch Handler — When user clicks PROCESS BATCH
------------------------------------------------------- */
processBatchBtn.addEventListener('click', async () => {

  let lines = [];

  // 1) Read pasted text
  const paste = batchPaste.value.trim();
  if (paste) {
    const pastedLines = paste.split(/\r?\n/)
      .map(s => s.trim())
      .filter(Boolean);

    lines.push(...pastedLines);
  }

  // 2) Read file upload (optional)
  if (fileUpload.files && fileUpload.files.length > 0) {
    const file = fileUpload.files[0];
    try {
      const text = await readFileAsText(file);
      const fileLines = text.split(/\r?\n/)
        .map(s => s.trim())
        .filter(Boolean);

      lines.push(...fileLines);
    } catch (err) {
      alert("Error reading file: " + err.message);
      return;
    }
  }

  // No input?
  if (lines.length === 0) {
    alert("No input found. Paste text or upload a file.");
    return;
  }

  // Clean UI
  batchPaste.value = "";
  fileUpload.value = "";

  // API URL (your ngrok)
  const API = "https://meanwhile-subpericardiac-huey.ngrok-free.dev/moderate";

  // Process each line
  for (const txt of lines) {

    // Safety delay to avoid API overload
    await new Promise(r => setTimeout(r, 120));

    try {
      const response = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: txt })
      });

      let data;
      try {
        data = await response.json();
      } catch (err) {
        addResult(txt, "error", 0, "rejected", "error", "Invalid JSON from server");
        continue;
      }

      const payload = data.result || data.moderation_result || data || {};

      const category =
        payload.category ||
        payload.label ||
        "unknown";

      

      const action =
        payload.action ||
        payload.predicted_action ||
        "none";

      const reason =
        payload.reason ||
        payload.explanation ||
        "";

      let status;

// Rule 1 — Auto-reject toxic or violent content
if (category.toLowerCase().includes("toxic") ||
    category.toLowerCase().includes("violence")) {
  status = "rejected";

// Rule 2 — If API action is remove/block → reject
} else if (action &&
    (action.toLowerCase().includes("remove") ||
     action.toLowerCase().includes("block"))) {
  status = "rejected";

// Everything else approved
} else {
  status = "approved";
} 
      addResult(txt, category, status, action, reason);

    } catch (err) {
      addResult(txt, "network-error", 0, "rejected", "error", err.message);
    }
  }

  // Refresh table & stats
  renderResultsTable();
  updateStats();
});


/* ---------------------------------------
   Add Result to global state + UI
---------------------------------------- */
function addResult(text, category = 'N/A', status = 'pending', action = null, reason = null) {
  const id = nextId++;
  const row = { id, text, category, status };

  if (action !== null) row.action = action;
  if (reason !== null) row.reason = reason;

  results.unshift(row);
  addRecentAction(`${status === 'approved' ? 'Approved' : 'Rejected'}: ${truncate(text, 60)}`);

  renderResultsTable();
  updateStats();
}


/* -------------------------------
   Render Results Table
-------------------------------- */
function renderResultsTable() {
  resultsTableBody.innerHTML = "";

  results.forEach(r => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${r.id}</td>
      <td>${escapeHtml(truncate(r.text, 220))}</td>
      <td>${r.category}</td>
      
      <td class="${r.status === 'approved' ? 'status-approved' : 'status-rejected'}">${r.status}</td>
      <td>
        <button class="btn" data-act="approve" data-id="${r.id}">Approve</button>
        <button class="btn" data-act="reject" data-id="${r.id}">Reject</button>
      </td>
    `;
    resultsTableBody.appendChild(tr);
  });

  // Wire action buttons
  resultsTableBody.querySelectorAll("button[data-act]").forEach(btn => {
    btn.addEventListener("click", ev => {
      const id = Number(btn.dataset.id);
      const act = btn.dataset.act;
      const item = results.find(x => x.id === id);
      if (!item) return;

      if (act === "approve") {
        item.status = "approved";
      } else {
        item.status = "rejected";
      }

      addRecentAction(`${act === 'approve' ? 'Approved' : 'Rejected'} (manual): ${truncate(item.text,60)}`);
      renderResultsTable();
      updateStats();
    });
  });
}


/* -----------------------------------------
   Stats & Recent Actions
------------------------------------------ */
function updateStats() {
  const total = results.length;
  const approved = results.filter(r => r.status === 'approved').length;
  const rejected = results.filter(r => r.status === 'rejected').length;

  const pct = total === 0 ? 0 : Math.round((rejected / total) * 100);

  statTotal.textContent = total;
  statApproved.textContent = approved;
  statRejected.textContent = rejected;
  statUnsafePct.textContent = pct;

  recentActionsList.innerHTML = "";
  recentActions.slice(0, 8).forEach(a => {
    const li = document.createElement('li');
    li.textContent = a;
    recentActionsList.appendChild(li);
  });
}

function addRecentAction(text) {
  const ts = new Date().toLocaleString();
  recentActions.unshift(`${text} • ${ts}`);
  if (recentActions.length > 50) recentActions.pop();
}


/* -------------------------
   Utilities
--------------------------- */
function escapeHtml(str) {
  return str.replace(/[<>&"']/g, c =>
    ({ '<':'&lt;', '>':'&gt;', '&':'&amp;', '"':'&quot;', "'":'&#39;' }[c])
  );
}

function truncate(s, n = 100) {
  return s.length > n ? s.slice(0, n) + "..." : s;
}


/* -------------------------------
   Export CSV
-------------------------------- */
exportCsvBtn.addEventListener('click', () => {
  if (results.length === 0) {
    alert("No results to export.");
    return;
  }

  const rows = [['id', 'text', 'category', 'status']];

  results.slice().reverse().forEach(r => {
    rows.push([
      r.id,
      r.text.replace(/\n/g, " "),
      r.category,
      
      r.status
    ]);
  });

  const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n');

  const blob = new Blob([csv], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'moderation_results.csv';
  document.body.appendChild(a);
  a.click();
  a.remove();
});


/* -------------------------------
   Clear batch input only
-------------------------------- */

clearBatchBtn.addEventListener('click', () => {
    batchPaste.value = '';
    fileUpload.value = '';
    results.length = 0;           // CLEAR ALL BATCH RESULTS
    recentActions.length = 0;     // CLEAR RECENT ACTIONS (optional)
    renderResultsTable();         // REFRESH EMPTY TABLE
    updateStats();                // RESET COUNTERS
}); 

/*clearBatchBtn.addEventListener('click', () => {
  batchPaste.value = "";
  fileUpload.value = "";
}); */